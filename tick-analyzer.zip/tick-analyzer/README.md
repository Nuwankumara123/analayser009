# tick analyzer

A Pen created on CodePen.io. Original URL: [https://codepen.io/nuw/pen/ogvBREQ](https://codepen.io/nuw/pen/ogvBREQ).

